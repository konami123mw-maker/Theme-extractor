package com.s18.themeextractor

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.util.zip.ZipInputStream

private val Bg = Color(0xFF080D10)
private val Panel = Color(0xFF111A1F)
private val Green = Color(0xFF63D6A4)
private val Muted = Color(0xFF91A2AA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { S18App() }
    }
}

data class Report(val name: String, val type: String, val size: String, val sha: String, val details: List<String>, val extracted: List<String> = emptyList())

@Composable
fun S18App() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var report by remember { mutableStateOf<Report?>(null) }
    var status by remember { mutableStateOf("اختر ملف ثيم للبدء") }
    var busy by remember { mutableStateOf(false) }
    var exportFile by remember { mutableStateOf<File?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            busy = true
            status = "جارٍ فحص الملف..."
            scope.launch {
                val result = withContext(Dispatchers.IO) { inspectTheme(context, uri) }
                report = result.first
                exportFile = result.second
                status = result.first?.let { "اكتمل الفحص" } ?: "تعذر قراءة الملف"
                busy = false
            }
        }
    }
    val savePicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        val source = exportFile
        if (uri != null && source != null) {
            scope.launch {
                withContext(Dispatchers.IO) {
                    context.contentResolver.openOutputStream(uri)?.use { out -> source.inputStream().use { it.copyTo(out) } }
                }
                status = "تم تصدير ملف الموارد"
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Green, background = Bg, surface = Panel)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize().padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("S18", color = Green, fontSize = 30.sp)
                        Text("THEME EXTRACTOR", color = Color.White, fontSize = 18.sp)
                        Text("HONOR • MAGICOS • THEME TOOLS", color = Muted, fontSize = 10.sp)
                    }
                    Icon(Icons.Default.Inventory2, null, tint = Green, modifier = Modifier.size(42.dp))
                }
                Spacer(Modifier.height(22.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.FolderOpen, null, tint = Green, modifier = Modifier.size(38.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("استيراد ملف ثيم", color = Color.White, style = MaterialTheme.typography.titleMedium)
                        Text("HWT  •  HNT  •  HNT.OOO", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(14.dp))
                        Button(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Bg)) {
                            Text("اختيار ملف")
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (busy) CircularProgressIndicator(Modifier.size(17.dp), color = Green, strokeWidth = 2.dp)
                    else Icon(Icons.Default.Info, null, tint = Green)
                    Spacer(Modifier.width(8.dp))
                    Text(status, color = Muted, fontSize = 13.sp)
                }
                Spacer(Modifier.height(12.dp))
                report?.let { r ->
                    Text("نتيجة الفحص", color = Color.White, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp)) {
                            Text(r.name, color = Color.White, style = MaterialTheme.typography.titleSmall)
                            Text("النوع: ${r.type}    الحجم: ${r.size}", color = Green, fontSize = 12.sp)
                            Spacer(Modifier.height(8.dp))
                            LazyColumn(Modifier.weight(1f, fill = false)) {
                                items(r.details) { line -> Text("• $line", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 3.dp)) }
                            }
                            if (r.extracted.isNotEmpty()) {
                                Spacer(Modifier.height(8.dp))
                                Text("الموارد المستخرجة (${r.extracted.size})", color = Green, fontSize = 13.sp)
                                r.extracted.take(12).forEach { Text(it, color = Muted, fontSize = 11.sp) }
                                if (r.extracted.size > 12) Text("و ${r.extracted.size - 12} ملفًا آخر...", color = Muted, fontSize = 11.sp)
                                Spacer(Modifier.height(12.dp))
                                OutlinedButton(onClick = { savePicker.launch("S18_Extracted_Resources.zip") }, modifier = Modifier.fillMaxWidth()) {
                                    Icon(Icons.Default.ArrowDownward, null)
                                    Spacer(Modifier.width(6.dp)); Text("تصدير الموارد ZIP")
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
                Text("S18_THEME  •  Version 1.0", color = Color(0xFF53636B), fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
        }
    }
}

private fun inspectTheme(context: android.content.Context, uri: Uri): Pair<Report?, File?> {
    return try {
        val name = queryName(context, uri) ?: "theme_file"
        val input = context.contentResolver.openInputStream(uri) ?: return null to null
        val temp = File(context.cacheDir, "s18_input_${System.currentTimeMillis()}")
        input.use { src -> temp.outputStream().use { dst -> src.copyTo(dst) } }
        val ext = name.substringAfterLast('.', "unknown").lowercase()
        val bytes = temp.inputStream().use { input ->
            val buffer = ByteArray(16)
            val count = input.read(buffer)
            if (count <= 0) ByteArray(0) else buffer.copyOf(count)
        }
        val sha = sha256(temp)
        val size = "%.2f MB".format(temp.length() / 1024.0 / 1024.0)
        val details = mutableListOf("SHA-256: $sha", "أول 16 بايت: ${bytes.joinToString(" ") { "%02X".format(it) }}")
        var output: File? = null
        val extracted = mutableListOf<String>()
        val isZip = bytes.size >= 4 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4B.toByte()
        if (isZip) {
            val dir = File(context.cacheDir, "s18_extract_${System.currentTimeMillis()}").apply { mkdirs() }
            var total = 0L
            ZipInputStream(temp.inputStream().buffered()).use { zis ->
                while (true) {
                    val entry = zis.nextEntry ?: break
                    val safe = File(dir, entry.name).canonicalFile
                    if (!safe.path.startsWith(dir.canonicalPath + File.separator) && safe != dir) continue
                    if (!entry.isDirectory) {
                        safe.parentFile?.mkdirs()
                        safe.outputStream().use { out ->
                            val buffer = ByteArray(8192)
                            while (true) {
                                val n = zis.read(buffer)
                                if (n <= 0) break
                                total += n
                                if (total > 200L * 1024 * 1024) throw IllegalStateException("تجاوز الاستخراج حد 200MB")
                                out.write(buffer, 0, n)
                            }
                        }
                        extracted.add(entry.name)
                    }
                    zis.closeEntry()
                }
            }
            output = File(context.cacheDir, "S18_Extracted_Resources.zip")
            java.util.zip.ZipOutputStream(output.outputStream().buffered()).use { zos ->
                dir.walkTopDown().filter { it.isFile }.forEach { f ->
                    val relative = f.relativeTo(dir).invariantSeparatorsPath
                    zos.putNextEntry(java.util.zip.ZipEntry(relative))
                    f.inputStream().use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }
            details.add("صيغة ZIP معروفة؛ تم استخراج الموارد")
            details.add("إجمالي الموارد: ${extracted.size}")
        } else {
            details.add("لم يتم التعرف على توقيع ZIP في بداية الملف")
            details.add("لم تُجرَ محاولة لفك تشفير أو تجاوز حماية الملف")
            if (ext == "hnt" || ext == "ooo") details.add("الملف يحتاج إلى محلل صيغة موثّق قبل استخراج محتواه")
        }
        val type = when (ext) { "hwt" -> "HWT"; "hnt" -> "HNT"; "ooo" -> "HNT.OOO"; else -> ext.uppercase() }
        Report(name, type, size, sha, details, extracted) to output
    } catch (e: Exception) { null to null }
}

private fun queryName(context: android.content.Context, uri: Uri): String? {
    context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) return c.getString(0)
    }
    return uri.lastPathSegment
}

private fun sha256(file: File): String {
    val digest = MessageDigest.getInstance("SHA-256")
    file.inputStream().buffered().use { input ->
        val buffer = ByteArray(64 * 1024)
        while (true) { val n = input.read(buffer); if (n < 0) break; digest.update(buffer, 0, n) }
    }
    return digest.digest().joinToString("") { "%02x".format(it) }
}
